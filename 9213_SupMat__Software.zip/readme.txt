Requirements
Python >= 3.6 and PyTorch >= 1.6.0 (tested) 

CUDA 10.1, 10.2

Bert-as-service
https://github.com/hanxiao/bert-as-service

Transformers package from Huggingface (Required by using Transformers)
pip install transformers

tqdm package
pip install tqdm

termcolor package
pip install termcolor

overrides package
pip install overrides



Training with your own data.
Create a folder YourData under the data directory.
Put the train.txt, dev.txt and test.txt files (make sure the format is compatible, i.e. the first column is words and the last column are tags) under this directory. If you have a different format, simply modify the reader in config/reader.py.
Change the dataset argument to YourData when you run trainer.py.


By default, the model eval our saved model (without BERT) on SemEval 2010 Task 1 Spanish dataset.
python main.py  

To train the model with other datasets, Simply replace the arguments. 
python trainer.py --device=cuda:0 --dataset=YourData --model_folder=saved_models
for example:
python trainer.py --device=cuda:0 --mode=train --dataset=ontonotes --embedding_file=glove.6B.100d.txt

To train with BERT, first obtain the contextual embedding with the instructions in the (SynLSTM-for-NER)
https://github.com/xuuuluuu/SynLSTM-for-NER
python main.py --mode=train --dataset=ontonotes --embedding_file=glove.6B.100d.txt --context_emb=bert 


The code are created based on the code of https://github.com/allanj/pytorch_neural_crf


from transformers import BertModel, BertTokenizerFast, OpenAIGPTModel, OpenAIGPTTokenizer
from transformers import GPT2Model, GPT2Tokenizer, CTRLModel, CTRLTokenizer
from transformers import TransfoXLModel, TransfoXLTokenizer, XLNetModel, XLNetTokenizer, DistilBertModel, DistilBertTokenizer
from transformers import RobertaModel, RobertaTokenizerFast, XLMRobertaModel, XLMRobertaTokenizerFast
from transformers import AutoModelForMaskedLM
from transformers import AutoTokenizer
from transformers import AdamW, get_linear_schedule_with_warmup
from typing import List, Dict, Any
from src.config import Config
import torch.nn as nn
from termcolor import colored
import torch.optim as optim
from torch.optim.lr_scheduler import LambdaLR

from src.config.AutomaticWeightedLoss import AutomaticWeightedLoss


context_models = {
    'bert-base-uncased' : {  "model": BertModel,  "tokenizer" : BertTokenizerFast },
    'bert-base-cased' : {  "model": BertModel,  "tokenizer" : BertTokenizerFast },
    'bert-large-cased' : {  "model": BertModel,  "tokenizer" : BertTokenizerFast },
    'openai-gpt': {"model": OpenAIGPTModel, "tokenizer": OpenAIGPTTokenizer},
    'gpt2': {"model": GPT2Model, "tokenizer": GPT2Tokenizer},
    'ctrl': {"model": CTRLModel, "tokenizer": CTRLTokenizer},
    'transfo-xl-wt103': {"model": TransfoXLModel, "tokenizer": TransfoXLTokenizer},
    'xlnet-base-cased': {"model": XLNetModel, "tokenizer": XLNetTokenizer},
    'distilbert-base-cased': {"model": DistilBertModel, "tokenizer": DistilBertTokenizer},
    'roberta-base': {"model": RobertaModel, "tokenizer": RobertaTokenizerFast},
    'roberta-large': {"model": RobertaModel, "tokenizer": RobertaTokenizerFast},
    'xlm-roberta-base': {"model": XLMRobertaModel, "tokenizer": XLMRobertaTokenizerFast},
    'PlanTL-GOB-ES/roberta-base-ca': {"model": AutoModelForMaskedLM, "tokenizer": AutoTokenizer},
    'PlanTL-GOB-ES/roberta-base-bne': {"model": AutoModelForMaskedLM, "tokenizer": AutoTokenizer},
    'hfl/chinese-roberta-wwm-ext': {"model": BertModel, "tokenizer": BertTokenizerFast},
}

class WarmupLinearSchedule(LambdaLR):
    """ Linear warmup and then linear decay.
        Linearly increases learning rate from 0 to 1 over `warmup_steps` training steps.
        Linearly decreases learning rate from 1. to 0. over remaining `t_total - warmup_steps` steps.
    """
    def __init__(self, optimizer, warmup_steps, t_total, last_epoch=-1):
        self.warmup_steps = warmup_steps
        self.t_total = t_total
        super(WarmupLinearSchedule, self).__init__(optimizer, self.lr_lambda, last_epoch=last_epoch)

    def lr_lambda(self, step):
        if step < self.warmup_steps:
            return float(step) / float(max(1, self.warmup_steps))
        return max(0.0, float(self.t_total - step) / float(max(1.0, self.t_total - self.warmup_steps)))

def get_huggingface_optimizer_and_scheduler(config: Config, model: nn.Module,
                                            num_training_steps: int,
                                            weight_decay: float = 1e-2,
                                            eps: float = 1e-6,
                                            warmup_step: int = 0):
    """
    Copying the optimizer code from HuggingFace.
    """
    print(colored(f"Using AdamW optimizeer by HuggingFace with {config.learning_rate} learning rate, "
                  f"eps: {eps}, weight decay: {weight_decay}, warmup_step: {warmup_step}, ", 'yellow'))
    no_decay = ["bias", "LayerNorm.weight"]
    mtlloss = AutomaticWeightedLoss(2)
    optimizer_grouped_parameters = [
        {
            "params": [p for n, p in model.named_parameters() if not any(nd in n for nd in no_decay)],
            "weight_decay": weight_decay, 'lr': config.learning_rate, 'eps': eps,
        },
        {
            # "params": [p for n, p in model.named_parameters() if any(nd in n for nd in no_decay)],
            "params": mtlloss.parameters(),
            "weight_decay": 0.0,
        },
    ]
    optimizer = AdamW(optimizer_grouped_parameters)
    scheduler = get_linear_schedule_with_warmup(optimizer, num_warmup_steps=warmup_step, num_training_steps=num_training_steps)

    return optimizer, scheduler, mtlloss

class Optimizer(object):
    def __init__(self, config:Config,
                 model: nn.Module,
                 num_training_steps: int,
                 weight_decay: float = 1e-2,
                 eps: float = 1e-6,
                 warmup_step: int = 0):
        self.args = config
        self.train_step = 0
        self.learning_rate = config.learning_rate
        self.max_step = num_training_steps
        self.warmup_step = 10000
        print(colored(f"Using AdamW optimizeer by HuggingFace with {config.learning_rate} learning rate, "
                      f"eps: {eps}, weight decay: {weight_decay}, warmup_step: {warmup_step}, ", 'yellow'))
        no_decay = ["bias", "LayerNorm.weight"]
        self.mtlloss = AutomaticWeightedLoss(2)
        optimizer_grouped_parameters = [
            {
                "params": [p for n, p in model.named_parameters() if not any(nd in n for nd in no_decay)],
                "weight_decay": weight_decay, 'lr': config.learning_rate, 'eps': eps,
            },
            {
                # "params": [p for n, p in model.named_parameters() if any(nd in n for nd in no_decay)],
                "params": self.mtlloss.parameters(),
                "weight_decay": 0.0,
            },
        ]
        self.optimizer = AdamW(optimizer_grouped_parameters)
        self.scheduler = None
        if config.inference_type == 'biaffine':
            self.scheduler = optim.lr_scheduler.CosineAnnealingLR(self.optimizer, T_max=self.max_step, eta_min=1e-6)
        elif config.inference_type == 'crf':
            self.scheduler = get_linear_schedule_with_warmup(self.optimizer, num_warmup_steps=self.warmup_step, num_training_steps=self.max_step)
        # lr_scheduler = None
        # if args.scheduler == 'cosine':
        #     lr_scheduler = optim.lr_scheduler.CosineAnnealingLR(self.optimizer, T_max=args.max_step, eta_min=1e-6)
        # elif args.scheduler == 'step':
        #     lr_scheduler = optim.lr_scheduler.StepLR(self.optimizer, step_size=args.decay_step, gamma=args.decay)
        # elif args.scheduler == 'exponent':
        #     def lr_lambda(step):
        #         return args.decay ** (step / args.decay_step)
        #     lr_scheduler = optim.lr_scheduler.LambdaLR(self.optimizer, lr_lambda)
        # elif args.scheduler == 'inv_sqrt':
        #     def lr_lambda(step):
        #         if step == 0 and args.warmup_step == 0:
        #             return 1.
        #         else:
        #             return 1. / (step ** 0.5) if step > args.warmup_step else step / (args.warmup_step ** 1.5)
        #
        #     lr_scheduler = optim.lr_scheduler.LambdaLR(self.optimizer, lr_lambda)
        # elif args.scheduler == 'linear':
        #     lr_scheduler = WarmupLinearSchedule(self.optimizer, warmup_steps=args.warmup_step, t_total=args.max_step)
        # else:
        #     pass
        # self.lr_scheduler = lr_scheduler

    def step(self):
        self.optimizer.step()
        # self.optimizer.zero_grad()
        # self.scheduler.step()
        self.train_step += 1
        if self.scheduler is not None:
            if self.args.inference_type == 'biaffine':
                if self.train_step < self.warmup_step:
                    curr_lr = self.learning_rate * self.train_step / self.warmup_step
                    self.optimizer.param_groups[0]['lr'] = curr_lr
                else:
                    self.scheduler.step()
            elif self.args.inference_type == 'crf':
                self.scheduler.step()

        self.optimizer.zero_grad()

    def zero_grad(self):
        self.optimizer.zero_grad()

    def lr_schedule(self):
        self.scheduler.step()

    def lr_decay(self, decay_factor=0.98):
        self.optimizer.param_groups[0]['lr'] *= decay_factor

    @property
    def step_num(self):
        return self.train_step

    def get_lr(self):
        current_lr = self.optimizer.param_groups[0]['lr']
        return current_lr
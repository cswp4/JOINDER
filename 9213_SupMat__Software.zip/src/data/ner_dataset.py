# 
# @author: Allan
#

from tqdm import tqdm
from typing import List, Dict
from torch.utils.data import Dataset
from torch.utils.data._utils.collate import default_collate
import collections
import numpy as np
from src.data.data_utils import convert_iobes, build_label_idx, check_all_labels_in_dict, check_all_obj_is_None, build_span_label_idx, build_deplabel_idx, build_posTag_idx
from collections import namedtuple
from src.data import Instance
from src.data.data_utils import UNK
import re

Feature = namedtuple('Feature', 'words word_seq_len context_emb chars char_seq_lens postag_ids dephead_ids deplabel_ids labels span_label_ids non_pad_mask')
Feature.__new__.__defaults__ = (None,) * len(Feature._fields)


class NERDataset(Dataset):

    def __init__(self, file: str,
                 is_train: bool,
                 # postag2idx: Dict[str, int] = None,
                 deplabel2idx: Dict[str, int] = None,
                 span_label2idx: Dict[str, int] = None,
                 label2idx: Dict[str, int] = None,
                 number: int = -1):
        """
        Read the dataset into Instance
        """
        ## read all the instances. sentences and labels
        insts = self.read_txt(file=file, number=number)
        self.insts = insts
        if is_train:
            print(f"[Data Info] Using the training set to build label index")
            assert label2idx is None
            ## build label to index mapping. e.g., B-PER -> 0, I-PER -> 1
            idx2labels, label2idx = build_label_idx(insts)
            self.idx2labels = idx2labels
            self.label2idx = label2idx
            idx2span_labels, span_label2idx = build_span_label_idx(insts)
            self.idx2span_labels = idx2span_labels
            self.span_label2idx = span_label2idx
            deplabel2idx, root_dep_label_id = build_deplabel_idx(insts)
            self.deplabel2idx = deplabel2idx
            # self.postag2idx = build_posTag_idx(insts)
        else:
            assert label2idx is not None ## for dev/test dataset we don't build label2idx, pass in label2idx argument
            self.label2idx = label2idx
            self.deplabel2idx = deplabel2idx
            self.span_label2idx = span_label2idx
            # self.postag2idx = postag2idx
            # check_all_labels_in_dict(insts=insts, posTag2idx=self.postag2idx, deplabel2idx=self.deplabel2idx, label2idx=self.label2idx)

    def convert_instances_to_feature_tensors(self, word2idx: Dict[str, int], char2idx: Dict[str, int], posTag2idx: Dict[str, int],
                                             deplabel2idx: Dict[str, int],
                                             span_label2idx: Dict[str, int],
                                             elmo_vecs: np.ndarray = None):
        self.inst_ids = []
        for i, inst in enumerate(self.insts):
            words = inst.words
            word_ids = []
            char_ids = []
            output_ids = []
            char_seq_lens = []
            for word in words:
                if word in word2idx:
                    word_ids.append(word2idx[word])
                else:
                    word_ids.append(word2idx[UNK])
                char_id = []
                char_seq_lens.append(len(word))
                for c in word:
                    if c in char2idx:
                        char_id.append(char2idx[c])
                    else:
                        char_id.append(char2idx[UNK])
                char_ids.append(char_id)
            if inst.labels is not None:
                for label in inst.labels:
                    output_ids.append(self.label2idx[label])
            context_emb = elmo_vecs[i] if elmo_vecs is not None else None

            # create span_label gold map
            s = 0
            ner_tabs = dict()
            n = len(inst.labels)
            for i, label in enumerate(inst.labels):
                if i + 1 < n and label == 'O' and inst.labels[i + 1] != 'O':
                    s = i + 1
                if label != 'O':
                    if i + 1 == n:
                        ner_tag = label.split('-')[1]
                        ner_tabs[(s, i)] = span_label2idx[ner_tag]
                    elif inst.labels[i + 1] == 'O':
                        ner_tag = label.split('-')[1]
                        ner_tabs[(s, i)] = span_label2idx[ner_tag]
            # end span_label gold map
            dep_labels = inst.deplabels
            deplabel_ids = [deplabel2idx[dep_label] for dep_label in dep_labels] if dep_labels else [-100] * len(words)
            dephead_ids = inst.depheads
            non_pad_mask = [1] * len(inst.labels)
            postag_ids = [posTag2idx[postag] for postag in inst.posTags] if inst.posTags else [-100] * len(words)
            self.inst_ids.append(Feature(words = word_ids, word_seq_len = len(words), context_emb = context_emb,
                                         chars = char_ids, char_seq_lens = char_seq_lens, postag_ids = postag_ids,
                                         dephead_ids = dephead_ids, deplabel_ids = deplabel_ids,
                                         labels = output_ids if inst.labels is not None else None,
                                         span_label_ids=ner_tabs, non_pad_mask=non_pad_mask))


    def read_txt(self, file: str, number: int = -1) -> List[Instance]:
        print(f"[Data Info] Reading file: {file}, labels will be converted to IOBES encoding")
        print(f"[Data Info] Modify src/data/ner_dataset.read_txt function if you have other requirements")
        insts = []
        with open(file, 'r', encoding='utf-8') as f:
            words = ['root']
            ori_words = ['root']
            posTags = ['root']
            depheads = [0]
            deplabels = ['root']
            labels = ['O']
            for line in tqdm(f.readlines()):
                line = line.rstrip()
                if line == "":
                    labels = convert_iobes(labels)
                    insts.append(Instance(words=words, ori_words=ori_words, posTags=posTags, depheads=depheads, deplabels=deplabels, labels=labels))
                    words = ['root']
                    ori_words = ['root']
                    posTags = ['root']
                    depheads = [0]
                    deplabels = ['root']
                    labels = ['O']
                    if len(insts) == number:
                        break
                    continue
                ls = line.split('\t')
                word, pos, dephead, deplabel, label = ls[1], ls[3], int(ls[6]), ls[7], ls[-1]
                ori_words.append(word)
                word = re.sub('\d', '0', word)
                words.append(word)
                posTags.append(pos)
                depheads.append(dephead) ## because of 0-indexed. 现在直接读词的序号，不减1
                deplabels.append(deplabel)
                labels.append(label)
        print("number of sentences: {}".format(len(insts)))
        return insts

    def __len__(self):
        return len(self.insts)

    def __getitem__(self, index):
        return self.inst_ids[index]

    def collate_fn(self, batch:List[Feature]):
        word_seq_lens = [len(feature.words) for feature in batch]
        max_seq_len = max(word_seq_lens)
        max_char_seq_len = -1
        for feature in batch:
            curr_max_char_seq_len = max(feature.char_seq_lens)
            max_char_seq_len = max(curr_max_char_seq_len, max_char_seq_len)
        for i, feature in enumerate(batch):
            padding_length = max_seq_len - len(feature.words)
            words = feature.words + [0] * padding_length
            chars = []
            char_seq_lens = feature.char_seq_lens + [1] * padding_length
            for word_idx in range(feature.word_seq_len):
                pad_char_length = max_char_seq_len - feature.char_seq_lens[word_idx]
                word_chars = feature.chars[word_idx] + [0] * pad_char_length
                chars.append(word_chars)
            for _ in range(max_seq_len - feature.word_seq_len):
                chars.append([0] * max_char_seq_len)

            dephead_ids = feature.dephead_ids + [0] * padding_length
            deplabel_ids = feature.deplabel_ids + [0] * padding_length
            postag_ids = feature.postag_ids + [0] * padding_length
            non_pad_mask = feature.non_pad_mask + [0] * padding_length
            labels = feature.labels + [0] * padding_length if feature.labels is not None else None
            span_label_ids = np.zeros((max_seq_len, max_seq_len), dtype=np.long)
            for s in range(len(feature.words)):
                for e in range(s, len(feature.words)):
                    # Note: unk_idx denotes the non-entity span, unk_idx = 1
                    span_label_ids[s, e] = feature.span_label_ids.get((s, e), 1)
            context_emb = None
            if feature.context_emb is not None:
                emb_size = feature.context_emb.shape[2]
                context_emb = np.zeros((max_seq_len, emb_size), dtype=np.float32)
                context_emb[:feature.word_seq_len, :] = feature.context_emb
            batch[i] = Feature(words=np.asarray(words),word_seq_len = feature.word_seq_len,context_emb = context_emb,
                               chars=np.asarray(chars), char_seq_lens=np.asarray(char_seq_lens), postag_ids=np.asarray(postag_ids),
                               dephead_ids=np.asarray(dephead_ids), deplabel_ids=np.asarray(deplabel_ids),
                               labels= np.asarray(labels) if labels is not None else None,
                               span_label_ids=span_label_ids, non_pad_mask=np.asarray(non_pad_mask))
        results = Feature(*(default_collate(samples) if not check_all_obj_is_None(samples) else None for samples in zip(*batch) ))
        # results = Feature(*(default_collate(samples) for samples in zip(*batch)))
        return results

# ##testing code to test the dataset loader
# train_dataset = NERDataset(file="data/conll2003_sample/train.txt",is_train=True)
# label2idx = train_dataset.label2idx
# dev_dataset = NERDataset(file="data/conll2003_sample/train.txt",is_train=False, label2idx=label2idx)
# test_dataset = NERDataset(file="data/conll2003_sample/train.txt",is_train=False, label2idx=label2idx)
#
# word2idx, _, char2idx, _ = build_word_idx(train_dataset.insts, dev_dataset.insts, test_dataset.insts)
# train_dataset.convert_instances_to_feature_tensors(word2idx=word2idx, char2idx=char2idx)
# dev_dataset.convert_instances_to_feature_tensors(word2idx=word2idx, char2idx=char2idx)
# test_dataset.convert_instances_to_feature_tensors(word2idx=word2idx, char2idx=char2idx)
#
#
# from torch.utils.data import DataLoader
# train_dataloader = DataLoader(train_dataset, batch_size=10, shuffle=True, num_workers=0, collate_fn=train_dataset.collate_fn)
# print(len(train_dataloader))
# for batch in train_dataloader:
#     print(batch.words)
#     exit(0)
#     # pass

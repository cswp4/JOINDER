from dataclasses import dataclass
from typing import List

@dataclass
class Instance:
	words: List[str]
	ori_words: List[str]
	posTags: List[str] = None
	depheads: List[int] = None
	deplabels: List[str] = None
	labels: List[str] = None
	# span_labels: List[str] = None
	prediction: List[str] = None


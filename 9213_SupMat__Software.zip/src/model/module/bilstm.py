import torch
import torch.nn as nn
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence


class BiLSTMEncoder(nn.Module):
    def __init__(self, args, input_dim:int):
        super(BiLSTMEncoder, self).__init__()

        self.bilstm = nn.LSTM(input_size=input_dim,
                              hidden_size=args.hidden_dim // 2,
                              num_layers=args.num_lstm_layer - 1,
                              dropout=args.lstm_drop,
                              batch_first=True,
                              bidirectional=True)
        self.drop_lstm = nn.Dropout(args.lstm_drop)

    def forward(self, embed_inputs, non_pad_mask=None):
        '''
        :param embed_inputs: (bz, seq_len, embed_dim)
        :param non_pad_mask: (bz, seq_len)
        :return:
        '''
        if non_pad_mask is None:
            non_pad_mask = embed_inputs.data.new_full(embed_inputs.shape[:2], 1)

        seq_lens = non_pad_mask.data.sum(dim=1)
        sort_lens, sort_idxs = torch.sort(seq_lens, dim=0, descending=True)
        pack_embed = pack_padded_sequence(embed_inputs[sort_idxs], lengths=sort_lens.cpu(), batch_first=True)
        pack_enc_out, _ = self.bilstm(pack_embed)
        enc_out, _ = pad_packed_sequence(pack_enc_out, batch_first=True)
        _, unsort_idxs = torch.sort(sort_idxs, dim=0, descending=False)
        enc_out = self.drop_lstm(enc_out)
        return enc_out[unsort_idxs]

#
# @author: Allan
#

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence
# allen version
# from src.model.module.bilstm_encoder import BiLSTMEncoder
# wlz version
from src.model.module.bilstm import BiLSTMEncoder

from src.model.module.linear_crf_inferencer import LinearCRF
from src.model.module.biaffine_inference import BiaffineScorer
from src.model.module.linear_encoder import LinearEncoder
from src.model.embedder import TransformersEmbedder
from src.model.module.TEtransformer import *
from src.model.module.dropout import *
from src.model.module.biaffine import *
from src.model.module.eisner import eisner
from src.config.config import InteractionFunction
from typing import Tuple


from src.data.data_utils import START_TAG, STOP_TAG, PAD


class TransformersCRF(nn.Module):

    def __init__(self, config):
        super(TransformersCRF, self).__init__()
        self.device = config.device
        self.enc_type = config.enc_type
        self.use_true_dephead = config.use_true_dephead
        self.max_deppath = config.max_deppath
        self.inference_type = config.inference_type
        # wd embedding
        # self.wd_embedding = nn.Embedding(num_embeddings=args.wd_vocab_size,
        #                                  embedding_dim=args.wd_embed_dim,
        #                                  padding_idx=0)

        self.embedder = TransformersEmbedder(transformer_model_name=config.embedder_type,
                                             parallel_embedder=config.parallel_embedder)

        # 词性embedding
        # self.tag_embedding = nn.Embedding(num_embeddings=config.pos_size,
        #                                   embedding_dim=config.tag_embed_dim,
        #                                   padding_idx=0)

        self.embedder_drop = config.dropout

        # encoding layer
        self.lstm_hidden_dim = config.hidden_dim
        if config.hidden_dim > 0:
            if config.enc_type == 'lstm':
                # self.encoder = BiLSTMEncoder(label_size=config.label_size, input_dim=self.embedder.get_output_dim(),
                #                             hidden_dim=config.hidden_dim, drop_lstm=config.dropout)
                self.encoder = BiLSTMEncoder(config, input_dim=self.embedder.get_output_dim())
                self.enc_drop = config.lstm_drop
            elif config.enc_type == 'adatrans':
                self.encoder = TETransformerEncoder(num_layers=config.attn_layer, d_model=self.embedder.get_output_dim(),
                                                    output_dim=config.hidden_dim,n_head=config.nb_heads,
                                                    feedforward_dim=2 * (self.embedder.get_output_dim()),
                                                    dropout=config.att_drop, after_norm=True, attn_type=config.enc_type, scale=False, dropout_attn=None, pos_embed=None)
                self.enc_drop = config.transformer_drop
        else:
            self.encoder = LinearEncoder(label_size=config.label_size, input_dim=self.embedder.get_output_dim())
        # Biaffine Dependency Parsing
        self.mlp_drop = config.mlp_drop
        self._activation = nn.ReLU()
        # self._activation = nn.ELU()
        # self._activation = nn.LeakyReLU(0.1)
        self.mlp_arc = NonlinearMLP(in_feature=config.hidden_dim,
                                    out_feature=config.arc_hidden_dim * 2,
                                    activation=self._activation)
        self.mlp_rel = NonlinearMLP(in_feature=config.hidden_dim,
                                    out_feature=config.rel_hidden_dim * 2,
                                    activation=self._activation)

        self.total_num = int((config.arc_hidden_dim + config.rel_hidden_dim) / 100)
        self.arc_num = int(config.arc_hidden_dim / 100)
        self.rel_num = int(config.rel_hidden_dim / 100)

        self.arc_biaffine = Biaffine(config.arc_hidden_dim, 1, bias=(True, False))
        self.rel_biaffine = Biaffine(config.rel_hidden_dim, config.rel_size, bias=(True, True))
        # Dependency Guide
        self.interaction_func = config.interaction_func
        self.num_lstm_layer = config.num_lstm_layer
        if self.interaction_func == InteractionFunction.dep:
            self.mlp_feature_layers = nn.Linear(config.hidden_dim, 2*config.hidden_dim).to(config.device)
            self.mlp_feature_head = nn.Linear(config.hidden_dim, 2*config.hidden_dim).to(config.device)
            self.mlp_feature_head2 = nn.Linear(config.hidden_dim, 2*config.hidden_dim).to(config.device)
            hidden_size = 2 * config.hidden_dim
            if config.num_lstm_layer > 1:
                self.add_lstms = nn.ModuleList()
                print("[Model Info] Building {} more LSTMs, with size: {} x {} (without dep label highway connection)".format(
                    config.num_lstm_layer - 1, hidden_size, config.hidden_dim))
                for i in range(config.num_lstm_layer - 1):
                    self.add_lstms.append(nn.LSTM(hidden_size, config.hidden_dim // 2, num_layers=1, batch_first=True, bidirectional=True).to(self.device))
            self.drop_lstm = nn.Dropout(config.lstm_drop).to(self.device)
        if config.inference_type == 'crf': # CRF decoding
            self.hidden2tag = nn.Linear(config.hidden_dim, config.label_size)
            self.inferencer = LinearCRF(label_size=config.label_size, label2idx=config.label2idx, add_iobes_constraint=config.add_iobes_constraint,
                                        idx2labels=config.idx2labels)
        elif config.inference_type == 'biaffine': # Biaffine decoding
            self.hidden2dim = nn.Linear(config.hidden_dim, 2 * config.hidden_dim)
            self.biaff_scorer = BiaffineScorer(2 * config.hidden_dim, ffnn_size=config.ffnn_size, num_cls=config.label_size, ffnn_drop=config.ffnn_drop)
        self.pad_idx = config.label2idx[PAD]

    def forward(self, words: torch.Tensor,
                    word_seq_lens: torch.Tensor,
                    orig_to_tok_index: torch.Tensor,
                    input_mask: torch.Tensor,
                    # posTag: torch.Tensor,
                    true_head: torch.Tensor,
                    # true_rel: torch.Tensor,
                    non_pad_mask: torch.Tensor) -> torch.Tensor:
        """
        Calculate the negative loglikelihood.
        :param words: (batch_size x max_seq_len)
        :param word_seq_lens: (batch_size)
        :param context_emb: (batch_size x max_seq_len x context_emb_size)
        :param chars: (batch_size x max_seq_len x max_char_len)
        :param char_seq_lens: (batch_size x max_seq_len)
        :param labels: (batch_size x max_seq_len)
        :return: the total negative log-likelihood loss
        """
        word_rep = self.embedder(words, orig_to_tok_index, input_mask)
        # if self.training:
        #     word_rep = timestep_dropout(word_rep, self.embedder_drop)
        # allen version
        # feature_out = self.encoder(word_rep, word_seq_lens)
        # wlz version
        feature_out = self.encoder(word_rep, non_pad_mask)
        if self.training:
            feature_out = timestep_dropout(feature_out, self.enc_drop)
        batch_size = word_rep.size(0)
        # sent_len = sorted_seq_tensor.size(1)
        # Biaffine Dependency Parsing
        arc_feat = self.mlp_arc(feature_out)
        rel_feat = self.mlp_rel(feature_out)
        arc_head, arc_dep = arc_feat.chunk(2, dim=-1)
        rel_head, rel_dep = rel_feat.chunk(2, dim=-1)

        if self.training:
            arc_head = timestep_dropout(arc_head, self.mlp_drop)
            arc_dep = timestep_dropout(arc_dep, self.mlp_drop)
        arc_score = self.arc_biaffine(arc_dep, arc_head).squeeze(-1)

        if self.training:
            rel_head = timestep_dropout(rel_head, self.mlp_drop)
            rel_dep = timestep_dropout(rel_dep, self.mlp_drop)
        rel_score = self.rel_biaffine(rel_dep, rel_head)

        # start arc_score_guide * enc_outs
        if self.interaction_func == InteractionFunction.dep and self.num_lstm_layer >1 and self.max_deppath !=0:
            if self.use_true_dephead == 0:
                # decode the pred_head from arc_score and get U_head
                mask = non_pad_mask.byte()
                mask[:, 0] = 0
                pred_head = eisner(arc_score, mask)
                # (bz, seq_len, seq_len)
                u_dphead = F.one_hot(pred_head,pred_head.size()[-1])
            else:
                head_idx = true_head.clone()
                for j in range(batch_size):
                    for i, head in enumerate(head_idx[j]):
                        if i >= word_seq_lens[j]:
                            break
                        else:
                            if head == 0:
                                head_idx[j][i] = i  ## appended it self.
                            else:
                                head_idx[j][i] = head
                u_dphead = F.one_hot(head_idx, head_idx.size()[-1])

            top_dphead = u_dphead
            u_dppath = u_dphead

            if self.max_deppath >= max(word_seq_lens) or self.max_deppath == -1:
                self.max_deppath = max(word_seq_lens)
            for i in range(self.max_deppath - 1):
                # if u_dppath[:, :, 1].sum().item() == u_dppath.shape[1]:
                #     break
                top_u_dphead = self.calc_onehot_dephead(top_dphead, u_dphead)
                u_dppath = u_dppath + top_u_dphead.long()
                top_dphead = top_u_dphead

            # U2_head = torch.matmul(U_head.float(), U_head.float())
            # U2_head = U2_head.masked_fill(U_head.bool(), 0, )
            # U_deppath = U_head + U2_head
            # true_head2 = torch.argmax(U2_head, dim=1)
            # dep_head_emb = torch.gather(feature_out, 1,
            #                         head_idx[permIdx].view(batch_size, sent_len, 1).expand(batch_size, sent_len, self.lstm_hidden_dim))
            # dep_head2_emb = torch.gather(feature_out, 1,
            #                              true_head2[permIdx].view(batch_size, sent_len, 1).expand(batch_size,sent_len, self.lstm_hidden_dim))
            feature_out = F.relu(self.mlp_feature_layers(feature_out) + self.mlp_feature_head(torch.matmul(u_dppath.float(), feature_out)))

            sorted_seq_len, permIdx = word_seq_lens.sort(0, descending=True)
            _, recover_idx = permIdx.sort(0, descending=False)
            sorted_seq_tensor = feature_out[permIdx]
            packed_words = pack_padded_sequence(sorted_seq_tensor, sorted_seq_len.cpu(), True)
            lstm_out, _ = self.add_lstms[0](packed_words, None)
            lstm_out, _ = pad_packed_sequence(lstm_out, batch_first=True)  ## CARE: make sure here is batch_first, otherwise need to transpose.
            feature_out = self.drop_lstm(lstm_out)
            feature_out = feature_out[recover_idx]
        # bz, sent_len, hidden_dim -> bz, sent_len, label_size
        if self.inference_type == 'crf':
            lstm_scores = self.hidden2tag(feature_out)
        elif self.inference_type == 'biaffine':
            feature_out = self.hidden2dim(feature_out)
            lstm_scores = self.biaff_scorer(feature_out)
        return arc_score, rel_score, lstm_scores

    def calc_onehot_dephead(self, top_dephead, dephead):
        mask = top_dephead
        top_dephead = torch.matmul(top_dephead.float(), dephead.float())
        top_dephead = top_dephead.masked_fill(mask.bool(), 0, )
        return top_dephead.long()

    def decode(self, words: torch.Tensor,
                    word_seq_lens: torch.Tensor,
                    orig_to_tok_index: torch.Tensor,
                    input_mask,
                    **kwargs) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Decode the batch input
        :param batchInput:
        :return:
        """
        word_rep = self.embedder(words, orig_to_tok_index, input_mask)
        feature_out = self.encoder(word_rep, word_seq_lens)
        features = self.hidden2tag(feature_out)
        bestScores, decodeIdx = self.inferencer.decode(features, word_seq_lens)
        return bestScores, decodeIdx

    def calc_ner_loss_crf(self, pred_scores, word_seq_lens, true_labels):
        batch_size = true_labels.size(0)
        sent_len = true_labels.size(1)
        dev_num = true_labels.get_device()
        curr_dev = torch.device(f"cuda:{dev_num}") if dev_num >= 0 else torch.device("cpu")
        maskTemp = torch.arange(1, sent_len + 1, dtype=torch.long, device=curr_dev).view(1, sent_len).expand(batch_size, sent_len)
        mask = torch.le(maskTemp, word_seq_lens.view(batch_size, 1).expand(batch_size, sent_len))
        unlabed_score, labeled_score = self.inferencer(pred_scores, word_seq_lens, true_labels, mask)
        return unlabed_score - labeled_score

    def calc_ner_loss_biaffine(self, span_score, true_labels):
        '''
        :param span_score: (b, t, t, c)
        :param ner_ids: (b, t, t)
        :return:
        '''
        num_ner = true_labels.gt(0).sum()
        num_cls = span_score.size(-1)
        loss = F.cross_entropy(span_score.reshape(-1, num_cls), true_labels.reshape(-1), ignore_index=0, reduction='sum')
        return loss / num_ner

    def decode2(self, pred_scores, word_seq_lens):
        bestScores, decodeIdx = self.inferencer.decode(pred_scores, word_seq_lens)
        return bestScores, decodeIdx

    def metric_dep_evaluate(self, pred_arcs, pred_rels, true_heads, true_rels, non_pad_mask=None, punc_mask=None):
        '''
        :param pred_arcs: (bz, seq_len, seq_len)
        :param pred_rels:  (bz, seq_len, seq_len, rel_size)
        :param true_heads: (bz, seq_len)  包含padding
        :param true_rels: (bz, seq_len)
        :param non_pad_mask: (bz, seq_len)
        :param punc_mask: (bz, seq_len)  含标点符号为1
        if punc_mask is not None, we will omit punctuation
        :return:
        '''
        non_pad_mask = non_pad_mask.byte()
        non_pad_mask[:, 0] = 0  # mask out <root>
        # 解码过程
        pred_heads, pred_rels = self.dep_decode(pred_arcs, pred_rels, non_pad_mask)

        # 统计过程
        non_punc_mask = (~punc_mask if punc_mask is not None else 1)
        pred_heads_correct = (pred_heads == true_heads) * non_pad_mask * non_punc_mask
        pred_rels_correct = (pred_rels == true_rels) * pred_heads_correct
        arc_acc = pred_heads_correct.sum().item()
        rel_acc = pred_rels_correct.sum().item()
        total_arcs = (non_pad_mask * non_punc_mask).sum().item()

        return arc_acc, rel_acc, total_arcs

    def calc_dep_loss(self, pred_arcs, pred_rels, true_heads, true_rels, non_pad_mask):
        '''
        :param pred_arcs: (bz, seq_len, seq_len)
        :param pred_rels:  (bz, seq_len, seq_len, rel_size)
        :param true_heads: (bz, seq_len)  包含padding
        :param true_rels: (bz, seq_len)
        :param non_pad_mask: (bz, seq_len) 有效部分mask
        :return:
        '''
        # non_pad_mask[:, 0] = 0  # mask out <root>
        # non_pad_mask = non_pad_mask.byte()
        pad_mask = (non_pad_mask == 0)

        bz, seq_len, _ = pred_arcs.size()
        masked_true_heads = true_heads.masked_fill(pad_mask, -1)
        arc_loss = F.cross_entropy(pred_arcs.reshape(bz*seq_len, -1),
                                   masked_true_heads.reshape(-1),
                                   ignore_index=-1)

        bz, seq_len, seq_len, rel_size = pred_rels.size()

        out_rels = pred_rels[torch.arange(bz, device=pred_arcs.device, dtype=torch.long).unsqueeze(1),
                             torch.arange(seq_len, device=pred_arcs.device, dtype=torch.long).unsqueeze(0),
                             true_heads].contiguous()

        masked_true_rels = true_rels.masked_fill(pad_mask, -1)
        # (bz*seq_len, rel_size)  (bz*seq_len, )
        rel_loss = F.cross_entropy(out_rels.reshape(-1, rel_size),
                                   masked_true_rels.reshape(-1),
                                   ignore_index=-1)
        return arc_loss + rel_loss

    def calc_dep_acc(self, pred_arcs, pred_rels, true_heads, true_rels, non_pad_mask=None):
        '''a
        :param pred_arcs: (bz, seq_len, seq_len)
        :param pred_rels:  (bz, seq_len, seq_len, rel_size)
        :param true_heads: (bz, seq_len)  包含padding
        :param true_rels: (bz, seq_len)
        :param non_pad_mask: (bz, seq_len) 非填充部分mask
        :return:
        '''
        # non_pad_mask[:, 0] = 0  # mask out <root>
        _mask = non_pad_mask.bool()

        bz, seq_len, seq_len, rel_size = pred_rels.size()

        # (bz, seq_len)
        pred_heads = pred_arcs.data.argmax(dim=2)
        masked_pred_heads = pred_heads[_mask]
        masked_true_heads = true_heads[_mask]
        arc_acc = masked_true_heads.eq(masked_pred_heads).sum().item()

        total_arcs = non_pad_mask.sum().item()

        out_rels = pred_rels[torch.arange(bz, device=pred_arcs.device, dtype=torch.long).unsqueeze(1),
                             torch.arange(seq_len, device=pred_arcs.device, dtype=torch.long).unsqueeze(0),
                             true_heads].contiguous()
        pred_rels = out_rels.argmax(dim=2)
        masked_pred_rels = pred_rels[_mask]
        masked_true_rels = true_rels[_mask]
        rel_acc = masked_true_rels.eq(masked_pred_rels).sum().item()

        return arc_acc, rel_acc, total_arcs

    def dep_decode(self, pred_arc_score, pred_rel_score, mask):
        '''
        :param pred_arc_score: (bz, seq_len, seq_len)
        :param pred_rel_score: (bz, seq_len, seq_len, rel_size)
        :param mask: (bz, seq_len)  pad部分为0
        :return: pred_heads (bz, seq_len)
                 pred_rels (bz, seq_len)
        '''
        bz, seq_len, _ = pred_arc_score.size()
        # pred_heads = mst_decode(pred_arc_score, mask)
        # mask[:, 0] = 0  # mask out <root>
        pred_heads = eisner(pred_arc_score, mask)
        pred_rels = pred_rel_score.argmax(dim=-1)
        # pred_rels = pred_rels.gather(dim=-1, index=pred_heads.unsqueeze(-1)).squeeze(-1)
        pred_rels = pred_rels[torch.arange(bz, dtype=torch.long, device=pred_arc_score.device).unsqueeze(1),
                              torch.arange(seq_len, dtype=torch.long, device=pred_arc_score.device).unsqueeze(0),
                              pred_heads].contiguous()
        return pred_heads, pred_rels

    def ner_span_gold(self, ner_ids, sent_lens, span_label_ids=None):
        '''
        :param ner_ids: (b, t, t)
        :param sent_lens:  (b, )
        :param ner_vocab:
        :return:
        '''
        gold_res = []
        for ner_id, l in zip(ner_ids, sent_lens):
            res = []
            for s in range(l):
                for e in range(s, l):
                    type_id = ner_id[s, e].item()
                    if type_id not in [span_label_ids['<PAD>'], span_label_ids['<UNK>']]:
                        res.append((s, e, type_id))
            gold_res.append(res)

        return gold_res

    def ner_span_pred(self, pred_score, sent_lens, span_label_ids=None):
        '''
        :param pred_score: (b, t, t, c)
        :param sent_lens: (b, )
        # :param mask: (b, t)  1对应有效部分，0对应pad填充
        :return:
        '''
        # (b, t, t)
        type_idxs = pred_score.detach().argmax(dim=-1)
        # (b, t, t)
        span_max_score = pred_score.detach().gather(dim=-1, index=type_idxs.unsqueeze(-1)).squeeze(-1)
        final = []
        for span_score, tids, l in zip(span_max_score, type_idxs, sent_lens):
            cands = []
            for s in range(l):
                for e in range(s, l):
                    type_id = tids[s, e].item()
                    if type_id not in [span_label_ids['<PAD>'], span_label_ids['<UNK>']]:
                        cands.append((s, e, type_id, span_score[s, e].item()))

            pre_res = []
            for s, e, cls, _ in sorted(cands, key=lambda x: x[3], reverse=True):
                for s_, e_, _ in pre_res:
                    if s_ < s <= e_ < e or s < s_ <= e < e_:  # flat ner
                        break
                    if s <= s_ <= e_ <= e or s_ <= s <= e <= e_:  # nested ner
                        break
                else:
                    pre_res.append((s, e, cls))
            final.append(pre_res)

        return final

    def calc_span_acc(self, preds, golds, return_prf=False):
        '''
        :param preds: [(s, e, cls_id) ...]
        :param golds: [(s, e, cls_id) ...]
        :param return_prf: if True, return prf value, otherwise return number value
        :return:
        '''
        assert len(preds) == len(golds)
        nb_pred, nb_gold, nb_right = 0, 0, 0
        for pred_spans, gold_spans in zip(preds, golds):
            pred_span_set = set(pred_spans)
            gold_span_set = set(gold_spans)
            nb_pred += len(pred_span_set)
            nb_gold += len(gold_span_set)
            nb_right += len(pred_span_set & gold_span_set)

        if return_prf:
            return self.calc_span_prf(nb_right, nb_pred, nb_gold)
        else:
            return nb_right, nb_pred, nb_gold

    def calc_span_prf(self, nb_right, nb_pred, nb_gold):
        p = nb_right / (nb_pred + 1e-30)
        r = nb_right / (nb_gold + 1e-30)
        f = (2 * nb_right) / (nb_gold + nb_pred + 1e-30)
        return p*100, r*100, f*100